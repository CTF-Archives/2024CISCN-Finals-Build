#ifndef THERMOSTAT_LOGIC_FUNC_H
#define THERMOSTAT_LOGIC_FUNC_H

int thermostat_logic_init(void * sub_proc,void * para);
int thermostat_logic_start(void * sub_proc,void * para);

#endif
