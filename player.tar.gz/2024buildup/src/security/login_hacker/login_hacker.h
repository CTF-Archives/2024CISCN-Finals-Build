#ifndef HACKER_H
#define HACKER_H
 
 
int hacker_init (void * sub_proc, void * para);
int hacker_start (void * sub_proc, void * para);

#endif
