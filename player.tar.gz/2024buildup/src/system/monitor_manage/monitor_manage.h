#ifndef MONITOR_MANAGE_H
#define MONITOR_MANAGE_H
int monitor_manage_init(void * sub_proc,void * para);
int monitor_manage_start(void * sub_proc,void * para);

#endif
