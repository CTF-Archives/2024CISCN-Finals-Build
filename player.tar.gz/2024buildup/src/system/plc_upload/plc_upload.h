#ifndef PLC_UPLOAD_H
#define PLC_UPLOAD_H
int plc_upload_init(void * sub_proc,void * para);
int plc_upload_start(void * sub_proc,void * para);

#endif
