#ifndef AUDIT_STORE_H
#define AUDIT_STORE_H
int audit_store_init(void * sub_proc,void * para);
int audit_store_start(void * sub_proc,void * para);

#endif
