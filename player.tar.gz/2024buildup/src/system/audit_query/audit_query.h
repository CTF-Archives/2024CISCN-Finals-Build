#ifndef AUDIT_QUERY_H
#define AUDIT_QUERY_H
int audit_query_init(void * sub_proc,void * para);
int audit_query_start(void * sub_proc,void * para);

#endif
