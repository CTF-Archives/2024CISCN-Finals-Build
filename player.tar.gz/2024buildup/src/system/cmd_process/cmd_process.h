#ifndef CMD_PROCESS_H
#define CMD_PROCESS_H
int cmd_process_init(void * sub_proc,void * para);
int cmd_process_start(void * sub_proc,void * para);

#endif
