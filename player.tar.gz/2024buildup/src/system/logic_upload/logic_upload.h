#ifndef LOGIC_UPLOAD_H
#define LOGIC_UPLOAD_H
int logic_upload_init(void * sub_proc,void * para);
int logic_upload_start(void * sub_proc,void * para);

#endif
