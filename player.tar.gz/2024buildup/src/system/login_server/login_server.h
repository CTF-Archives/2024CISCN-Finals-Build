#ifndef LOGIN_SERVER_H
#define LOGIN_SERVER_H
 
 
int login_server_init (void * sub_proc, void * para);
int login_server_start (void * sub_proc, void * para);
#endif
