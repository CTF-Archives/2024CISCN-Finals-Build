#ifndef LOGIC_STORE_H
#define LOGIC_STORE_H
int logic_store_init(void * sub_proc,void * para);
int logic_store_start(void * sub_proc,void * para);

#endif
